#!/bin/sh

pkill mosquitto
