# Testing MQTTClient with mosquitto

## TLS

ca, server and client certificates generated with https://github.com/owntracks/tools/tree/master/TLS

## Run
./mosquitto.sh

