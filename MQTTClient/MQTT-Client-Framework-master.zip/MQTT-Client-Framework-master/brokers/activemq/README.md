# testing MQTTClient with activemq

* Download from https://activemq.apache.org/download.html

* untar archive

* run `bin/activemq start`
* check on `http://localhost:8161`, login as `admin:admin`
* run `bin/activemq stop`
